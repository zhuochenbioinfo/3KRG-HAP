[3KRG-HAP]

Haplotype marker based on 3,000 Rice Genomes (3K-RG) Project for genome-wide subpopulation ancestry inference.

The 3,000 Rice Genomes Project released the resequencing data of over 3,000 rice samples worldwide. 3K-RG population consists of two subspecies and multiple subpopulations. Within them, the four subpopulations with largest sample number are indica, tropical japonica, temperate japonica and aus.

Here I introduce a haplotype-based pipeline for subpopulation ancestry inference using 3K-RG as a background population.

NOTICE 1: This is a highly specialized pipeline and may be awkward for other uses. But some scripts in this pipeline may be usable for other situations.

NOTICE 2: The formulas and pictures in this page may not be displayed properly in some regions due to local Internet policies.

For more details, please check our publication: 
Zhuo Chen, Xiuxiu Li, Hongwei Lu, Qiang Gao, Huilong Du, Hua Peng, Peng Qin, Chengzhi Liang. Genomic atlases of introgression and differentiation reveal breeding footprints in Chinese cultivated rice. Journal of Genetics and Genomics, 2020, ISSN 1673-8527, https://doi.org/10.1016/j.jgg.2020.10.006.

If you have any questions, suggestions or interests about this project, please feel free to contact: chenomics@163.com or zhuochen@genetics.ac.cn

------------------------------------------------

0. Reference genome
Reference genome used in this pipeline is japonica rice Nipponbare genome version IRGSP 1.0. See: http://rice.uga.edu/

1. Required softwares
(1) BWA: https://github.com/lh3/bwa
(2) SAMtools (Version 1.9) 
(2)	GATK4: https://gatk.broadinstitute.org
(3)	Perl (version 5)
(4)	R (version > 3.4) with R package ggplot2

2. Read mapping and processing
Align the fastq format clean read data of query rice samples to Nipponbare reference genome.
(1) BWA for read mapping, remember to add "Read Group" tags that are necessary for SNP calling. 
(2) SAMtools for read sorting, filtering, and removing PCR duplication. Remove non-primarily aligned reads and reads with mapping quality under 30.
Output file(s) is a sorted, filtered, deduplicated BAM format file for each query sample.

3. 3K-SNP genotyping
Use GATK4 for genotyping 3K-SNP from your BAM files.
GATK4 Recommended parameters:
(1) gatk4 HaplotypeCaller -I query1.bam -O query1.g.phased.vcf.gz -R ref.fasta -L 3K-SNP.bed -ERC GVCF
	gatk4 HaplotypeCaller -I query2.bam -O query2.g.phased.vcf.gz -R ref.fasta -L 3K-SNP.bed -ERC GVCF
(2) gatk4 CombineGVCFs -R ref.fasta --variant query1.g.phased.vcf.gz --variant query2.g.phased.vcf.gz --O all.g.vcf.gz
(3) gatk4 GenotypeGVCFs -R ref.fasta -V all.g.vcf.gz --force-output-intervals 3K-SNP.bed -O all.vcf.gz

You can also use UnifiedGenotyper from earlier versions of GATK (3.X), with parameters: -L 3K-SNP.bed and --output_mode EMIT_ALL_SITES.

4. run 3K-HAP pipe line
perl ./pipe_3KHAP/scripts/pipe_3KHAP.pl all.vcf.gz ./project_path/
