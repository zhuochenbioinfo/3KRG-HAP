library(ggplot2)

args <- commandArgs(TRUE)

chrlist <- args[1]
input <- args[2]
out.prefix <- args[3]

Mb <- 1000 * 1000

data <- read.delim(chrlist,header=F)
bin <- read.delim(input,header=F)

plot.height <- 6
plot.width <- length(data$V1) * 0.5 + 4

data$V1 <- factor(data$V1, levels = data$V1)
bin$V1 <- factor(bin$V1, levels = data$V1)

bin$V4 <- factor(bin$V4,levels=c("XI-admix","SP-aus","SP-ind","GJ-admix","SP-teGJ","SP-trGJ","Admixed"))

my.plot <- ggplot(data=data) +
  geom_rect(aes(xmin = as.numeric(V1) - 0.2, 
				xmax = as.numeric(V1) + 0.2 , 
				ymax = V2/Mb, ymin = 0),
				colour="black", fill = "white") +
  #coord_flip() +
  geom_rect(data=bin, aes(xmin = as.numeric(V1) - 0.18, 
				xmax = as.numeric(V1) + 0.18, 
				ymax = V2/Mb, ymin = V3/Mb, fill=V4)) +
  #scale_fill_manual(values = c("aus"="#FFFF00", "ind"="#556B2F", "INDICA"="#9ACD32", "tej"="#00BFFF", "trj"="#8B008B", "JAPONICA"="#0000FF")) +
  scale_fill_manual(values = c("SP-aus"="#FF0000", "SP-ind"="#FFD700", "XI-admix"="#FF8C00", "SP-teGJ"="#00FFFF", "SP-trGJ"="#800080", "GJ-admix"="#4080C0", "Admixed"="#C0C0C0")) +
  guides(fill=guide_legend(title="Origin")) +
  theme(axis.text.x = element_text(colour = "black"),
		panel.grid.major = element_blank(), 
		panel.grid.minor = element_blank(), 
		panel.background = element_blank()) + 
  scale_x_discrete(position = "top", name = "Chromosomes", limits = data$V1) +
  scale_y_continuous(trans="reverse") +
  ylab("Position (Mb)")

pdf(paste(out.prefix,"pdf",sep="."), width = plot.width, height = plot.height)
print(my.plot)
dev.off()
png(paste(out.prefix,"png",sep="."), width = plot.width, height = plot.height, units="in", res=600)
print(my.plot)
dev.off()
