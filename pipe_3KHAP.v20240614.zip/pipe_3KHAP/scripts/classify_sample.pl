use strict;
use warnings;

my $infile = shift;
my $outfile = shift;

# subspecies classification ratio
my $ratio1 = 0.6;
# subpopulation classification ratio
my $ratio2 = 0.6;

open(IN,"<$infile") or die $!;
open(OUT,">$outfile") or die $!;

print OUT "#sample\tsample_ss\tsample_sp\tXI-admix\tSP-ind\tSP-aus\tGJ-admix\tSP-teGJ\tSP-trGJ\tAdmixed\tNA\n";

while(<IN>){
	chomp;
	## sample	INDICA	JAPONICA	NA	admixed	aus	ind	tej	trj
	# #sample	NA	admixed	sp_aus	sp_ind	sp_tej	sp_trj	ss_INDx	ss_JAPx
	next if($_ =~ /^#/);
	my $sample_ss = "admixed";
	my $sample_sp = "admixed";
	#my($sample,$na,$admixed,$sp_aus,$sp_ind,$sp_tej,$sp_trj,$ss_IND,$ss_JAP) = split/\t/;
	# #sample Admixed GJ-admix        NA      SP-aus  SP-ind  SP-teGJ SP-trGJ XI-admix
	my($sample,$admixed,$ss_JAP,$na,$sp_aus,$sp_ind,$sp_tej,$sp_trj,$ss_IND) = split/\t/;
	my $ss_IND_all = $ss_IND + $sp_aus + $sp_ind;
	my $ss_JAP_all = $ss_JAP + $sp_tej + $sp_trj;
	if($ss_IND_all/($ss_IND_all + $ss_JAP_all) >= $ratio1){
		$sample_ss = "XI";
		if($sp_aus/($sp_aus + $sp_ind) >= $ratio2){
			$sample_sp = "SP-aus";
		}elsif($sp_ind/($sp_aus + $sp_ind) >= $ratio2){
			$sample_sp = "SP-ind";
		}
	}elsif($ss_JAP_all/($ss_IND_all + $ss_JAP_all) >= $ratio1){
		$sample_ss = "GJ";
		if($sp_tej/($sp_tej + $sp_trj) >= $ratio2){
			$sample_sp = "SP-teGJ";
		}elsif($sp_trj/($sp_tej + $sp_trj) >= $ratio2){
			$sample_sp = "SP-trGJ";
		}
	}
	print OUT "$sample\t$sample_ss\t$sample_sp\t$ss_IND\t$sp_ind\t$sp_aus\t$ss_JAP\t$sp_tej\t$sp_trj\t$admixed\t$na\n";
}
close IN;
close OUT;
