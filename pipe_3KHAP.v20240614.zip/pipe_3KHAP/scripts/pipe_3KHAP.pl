use strict;
use warnings;

# dependencies
# R packages: ggplot2, stringr, scales
my $Rscript = "/public-supool/software/R-3.4.3/bin/Rscript";

# Modify this path according to the location of your project
my $ref_path = "./pipe_3KHAP/";

my $in_vcf = shift;
my $out_path = shift;

my $usage = "USAGE:\nperl $0 <input VCF file> <output path>\n";

die $usage unless(defined $out_path);

# step 1: vcf to hap
print "STEP1: Haplotype construction...\n";
system("mkdir -p $out_path/01.vcf2hap/");
system("perl $ref_path/scripts/vcf2hap.varlist.pl --vcf $in_vcf --var $ref_path/data/3K-SNP.varlist.gz --out $out_path/01.vcf2hap/all --nohet");
# step 2: hap to NAF
print "STEP2: Haplotype matching...\n";
system("mkdir -p $out_path/02.hap2bin/");
system("perl $ref_path/scripts/match_hap_NAF.pl $out_path/01.vcf2hap/all.haplotype $ref_path/data/3K-HAP.haplotype.NAF_score.gz $out_path/02.hap2bin/");
# step 3: NAF to bin
print "STEP3: Haplotype to bin...\n";
my @naf_files = `ls $out_path/02.hap2bin/*.NAF.txt`;
foreach my $file(@naf_files){
	chomp($file);
	my ($name) = $file =~ /\S+\/(\S+)\.NAF.txt/;
	print "\tProcessing sample: $name\n";
	system("perl $ref_path/scripts/hapNAF2bin.pl $file $ref_path/data/3K-HAP.bin.bed.gz $out_path/02.hap2bin/$name.bin.txt");
	system("perl $ref_path/scripts/dissect_rice_bin.pl $out_path/02.hap2bin/$name.bin.txt > $out_path/02.hap2bin/$name.dissected_bin.txt");
	system("$Rscript $ref_path/scripts/plot_rice_bin.r pipe_3KHAP/data/rice.msu7.chr.len.txt $out_path/02.hap2bin/$name.dissected_bin.txt $out_path/02.hap2bin/$name.dissected_bin");
}
# step 4: summarize
print "STEP4: Summarize...\n";
system("perl $ref_path/scripts/stat_sample_bin.pl $out_path/02.hap2bin/ $out_path/sample.bin.summary.txt");
system("perl $ref_path/scripts/classify_sample.pl $out_path/sample.bin.summary.txt $out_path/sample.bin.summary.class.txt");
print "All Done!\n";
