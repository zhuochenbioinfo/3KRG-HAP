use strict;
use warnings;

my $inpath = shift;
my $outfile = shift;

my $suffix = "dissected_bin.txt";

my @types = ();
my %hash_type;
my %hash_sample;

my @files = `ls $inpath/*.$suffix`;

foreach my $file(@files){
	chomp($file);
	my($name) = $file =~ /\S+\/(\S+)\.$suffix/;
	$name =~ s/Sample_//;
	open(IN,"<$file") or die $!;
	while(<IN>){
		chomp;
		my($chr,$start,$end,$type) = split/\t/;
		unless(exists $hash_type{$type}){
			push @types, $type;
			$hash_type{$type}++;
		}
		$hash_sample{$name}{count}{$type}++;
	}
	close IN;
}

@types = sort @types;

open(OUT,">$outfile") or die $!;
print OUT "#sample\t".join("\t", @types)."\n";
foreach my $name(sort keys %hash_sample){
	my $line = "$name";
	foreach my $type(@types){
		my $value = 0;
		if(exists $hash_sample{$name}{count}{$type}){
			$value = $hash_sample{$name}{count}{$type};
		}
		$line .= "\t$value";
	}
	print OUT $line."\n";
}
close OUT;

