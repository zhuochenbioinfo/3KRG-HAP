use strict;
use warnings;

my $binfile = shift;

my $winsize = 100 * 1000;

open(IN,"<$binfile") or die $!;

my %hash_bin;
my %hash_count;
my $binsum = 0;

while(<IN>){
	chomp;
	next if($_ =~ /^#/);
	my($chr,$bin,$locinum,$aus,$ind,$tej,$trj) = split/\t/;
	my $start = $bin * $winsize + 1;
	my $end = ($bin + 1) * $winsize;
	my $type = "NA";
	if($locinum < 5){
		goto OUTPUT;
	}
	if(($aus + $ind) > 0.75){
		$type = "XI-admix";
		if($ind > ($aus + $ind) * 0.75){
			$type = "SP-ind";
		}elsif($aus > ($aus + $ind) * 0.75){
			$type = "SP-aus";
		}
	}elsif(($tej + $trj) > 0.75){
		$type = "GJ-admix";
		if($tej > ($tej + $trj) * 0.75){
			$type = "SP-teGJ";
		}elsif($trj > ($tej + $trj) * 0.75){
			$type = "SP-trGJ";
		}
	}else{
		$type = "Admixed";
	}
	OUTPUT:
	$binsum ++;
	$hash_count{$type}{count} ++;
	$hash_bin{$chr}{$start}{end} = $end;
	$hash_bin{$chr}{$start}{type} = $type;
	print "$chr\t$start\t$end\t$type\n";
}
close IN;
